# KRM Prototype Draft 0.8

**KRM / KRC / KRM-IF / KKI + native C++ KASF FastGen baseline + independent time-domain CSC/CDL research**  
Version: `0.8.0`  
Date: `2026-11-14`

> Research prototype. The native generator writes the actual KASF v1 container layout, but it is an independent baseline encoder—not a port of the complete KASF Rev.0.9.20 Generator/KASE/MRA optimization stack. The Reader bridge reproduces the audited local `KASF05_Reader.render()` equation and uses an explicitly experimental PCM quantizer. It is not an official KASF final PCM export.


## Independent time-domain CSC/CDL research track (Draft 0.2)

Draft 0.8 extends `krm_td_csc`, a separate NumPy-based research package for **Convolutional Sparse Coding and Convolutional Dictionary Learning directly on waveform samples**. It does not require frequency bins, STFT, or sinusoidal components. Translating a mature result to KASF frequency data is deferred and is not a constraint on this research.

The engine uses finite full-overlap linear convolution with explicit boundary handling, monotone backtracking FISTA, direct-time-domain ADMM + matrix-free CG, and alternating dictionary learning. FISTA now checks a proximal-gradient mapping residual before declaring a coefficient solve converged. Dictionary updates use projected gradients on unit-norm atoms and Armijo backtracking. This is a non-convex research baseline, not a globally optimal or long-audio production solver.

Install the optional research dependency and run the benchmarks:

```bash
python -m pip install -e ".[research]"
python benchmarks/run_research.py
python benchmarks/run_dictionary_learning.py --wav source.wav
```

Japanese quick guide: `README-TD-CSC-JA.md`. Research notes: `docs/CSC-RESEARCH-NOTES-JA.md`, `docs/TIME-DOMAIN-CSC-RESEARCH-DRAFT-0.1.md`, `docs/CONVOLUTIONAL-DICTIONARY-LEARNING-DRAFT-0.2.md`, and `docs/MULTISCALE-CSC-LITERATURE-REVIEW-DRAFT-0.1.md`. Measurements and limitations are in `benchmarks/REPORT-DRAFT-0.8.md`.

## What's new in Draft 0.6


0.6 adds a temporal identity layer to FastGen. The default mode writes a JSONL track map that associates per-frame components with stable channel-local track IDs. **It does not change KASF component bytes or Base PCM**; that invariant is tested against `--no-tracking`. A separate experimental refinement flag can alter component frequency/phase values, but remains off by default because synthetic quality tests showed Base SNR regressions in several cases.

1. **Native C++17 FastGen:** added `krm_proto/native/kasf_fastgen.cpp`, a standard-library-only baseline spectral-pursuit encoder. It reads WAV in bounded frame windows, applies periodic-Hann analysis, radix-2 FFT peak search, log-magnitude parabolic interpolation, weighted sine/cosine least-squares fitting, quantized residual pursuit, and writes KASF v1 components.
2. **Native Reader/Base path:** FastGen can render its just-written quantized components through the audited local Reader OLA equation inside the same native process and emit a Base PCM WAV. This avoids the slower Python per-sample render in the default bridge.
3. **KRM bridge:** `generate_and_capture()` now runs C++ FastGen → native local Reader OLA → experimental integer PCM quantization → KRC capture → KRM-IF, without requiring a second Python render pass.
4. **Python reference renderer retained:** `render_kasf_to_base_wav()` remains available for differential checks. In the current synthetic checks, C++ and Python produced byte-identical Base PCM at 8/16/24/32-bit widths.
5. **Header correction:** KASF v1 magic is `KASF`. Draft 0.4's Python decoder had mistakenly expected `KFSA`; the decoder, tests, and docs now use the actual source format and explicitly reject the transposed typo.
6. **Frequency-search improvement:** FFT peak selection now excludes bins below `min_hz` and outside KASF v1's 96 kHz representable frequency ceiling before selecting the strongest peak. A strong out-of-band low tone can no longer prematurely stop extraction of in-band peaks.
7. **Boundary improvement:** optional symmetric half-hop guard frames use phase-shifted first/last full-frame component seeds. This reduces the Hann boundary fade for steady or locally predictable content. It remains a heuristic approximation; all mismatch is retained in Raw Residual.
8. **KRC bridge resume:** if KRC capture is interrupted, `bridge-fast --resume` reuses the existing KASF/Base pair, verifies their SHA-256 hashes and Source-domain metadata, then resumes the journaled KRC capture without regenerating audio.
9. **Temporal component tracking:** added channel-local one-to-one greedy track association using predicted frequency, phase advance and amplitude continuity. FastGen writes `<output.kasf>.tracks.jsonl` with track IDs aligned to each frame's component order; the JSONL hash and row count are stored in the metadata sidecar.
10. **Audio-payload safety invariant:** default tracking is metadata-only. Tracking-enabled and `--no-tracking` runs with identical generation settings are tested to produce byte-identical KASF and Base WAV outputs.
11. **Experimental refinement isolated:** `--experimental-track-refine` enables phase-derived frequency refinement and center-phase compensation, but is not a default because the synthetic validation showed reduced Base SNR in multiple cases.
12. **Draft 0.6 regression tests:** 45 tests covered both tracker assignment modes, deterministic track maps, tracking/no-tracking payload identity, native/Python Base PCM parity, all PCM widths, KRC resume, and exact source restoration.

## Draft 0.8 verification summary

The complete test suite contains 66 passing tests. The time-domain research tests cover finite-convolution adjoints, atom-gradient finite differences, unit-norm constraints, deterministic dictionary learning, non-increasing CDL objective, FISTA warm starts and proximal-gradient mapping convergence. The direct time-domain research modules contain no FFT/STFT/DCT calls. Real-audio dictionary-learning experiments use training-only atom initialisation and held-out time windows; see `benchmarks/REPORT-DRAFT-0.8.md` for the modest and content-dependent results and the non-convergence caveats.

## Architecture and exactness invariant

Let `X[n,c]` be the Source PCM and `B[n,c]` be the Base PCM emitted by this **experimental local-Reader bridge**:

```text
R[n,c] = X[n,c] - B[n,c]
X[n,c] = B[n,c] + R[n,c]
```

KRC stores the exact signed integer residual as int64. The analysis and candidate layers cannot modify it. KRM-IF integrity hashes and block CRCs verify the stored data; `verify` can also compare a supplied Source WAV.

Important distinctions:

- `B` is the output of the local `KASF05_Reader` OLA equation plus the prototype quantizer described below.
- It is **not** claimed to be the final PCM that the full KASF web application would export after all app-level post-processing.
- Rev.0.9.20's local render helper is pre any separately defined global normalization policy. This prototype applies no global normalization.
- The KRM exact-restoration guarantee is for the Source/Base integer pair actually captured. It does not imply that the independently generated KASF file has the same quality as the optimized Rev.0.9.20 encoder.

## Native KASF FastGen

### Analysis path

Per channel and frame:

1. Apply periodic Hann: `w[n] = 0.5 - 0.5 cos(2πn/N)`.
2. Zero-pad to the next power of two and run an in-place radix-2 FFT.
3. Select the strongest eligible positive-frequency bin within `[min_hz, min(Nyquist, 96 kHz))`.
4. Refine the peak with parabolic interpolation of log magnitude.
5. Fit sine and cosine coefficients by weighted least squares to recover amplitude and phase.
6. Quantize to KASF v1's 24-bit frequency / 14-bit amplitude / 10-bit phase fields.
7. Subtract the **quantized** component from the frame and repeat up to `max_components`.
8. Sort components by frequency and write the KASF v1 frame/channel records.

This is intentionally a clear, fast baseline. It does not include the full KASF Rev.0.9.20 STN, HPSS guidance, Matrix Pencil, NOMP/GVP, ADMM, DPSS/SST, Haar Wavelet Packet MP, KASE search/optimization, cross-worker phase-seam correction, or Worker scheduling stack. The separate local temporal track map is only a greedy identity sidecar and does not make this algorithmically equivalent to the full KASF paths.

#### Temporal component tracking

After frame pursuit, the default tracker links components to channel-local IDs using predicted frequency, expected phase advance and amplitude continuity. It allows a two-frame detection gap. The default `greedy` assignment is fast; `--tracker-assignment hungarian` enables a global minimum-cost one-to-one assignment experiment. IDs are not instrument labels and can fragment or switch around close crossings. Real-audio comparisons show modest fragmentation reduction with extra cost, not a definitive tracking solution. Hungarian mode is capped at 256 active tracks and 256 components per channel/frame; use Greedy for larger limits. The JSONL map is hashed in the metadata sidecar.

The tracker is metadata-only by default: the KASF v1 component values and Base PCM are left untouched. `--no-tracking` disables the map. `--tracker-assignment greedy|hungarian` selects the association solver (default `greedy`); this changes only the track map. `--experimental-track-refine` enables a separate, audio-changing pitch/phase experiment; it is intentionally off by default because current tests showed Base SNR regressions on some synthetic cases.

## KASF v1 file layout

The writer follows the audited Rev.0.9.20 `buildKASF()` format:

- 32-byte little-endian header: ASCII `KASF`, uint32 version `1`, uint64 channel count, uint64 frame count, float64 frame duration seconds.
- Each frame/channel stores uint64 component count, then 6-byte components.
- Component packing: frequency 24 bits, amplitude 14 bits, phase 10 bits.
- Sample rate and original sample count are not stored by KASF v1. Keep the `.meta.json` sidecar with the KASF file.

### Edge guard mode

Enabled by default in the Python API and CLI. The analysis timeline adds one Reader hop before and after the Source timeline. The initial guard frame is seeded by analyzing the first complete Source window and shifting component phase backward by one hop. The trailing side uses the last complete Source window as a seed and shifts it forward. The Base renderer then crops back to the Source sample interval.

This method is intended to reduce boundary attenuation for sustained or locally predictable components; it is not a universal edge model. Use `--no-edge-pad` / `edge_pad=False` to disable it. The exact difference is always preserved in KRM Raw Residual.

## FastGen requirements and limits

- Python 3.10+
- C++17 compiler: GCC (`g++`) or Clang (`clang++`)
- KRM core and FastGen Python path use only the standard library; the separate `krm_td_csc` research package requires the optional NumPy dependency installed with `python -m pip install -e ".[research]"`; C++ uses only the standard library
- Input: RIFF/WAVE (not RF64), uncompressed integer PCM 8/16/24/32-bit
- FastGen supports 1–8 channels and 1,000–768,000 Hz
- Native Base WAV / `bridge-fast`: integer PCM WAV only (8/16/24/32-bit)
- KRM's Python WAV adapter supports uncompressed integer PCM WAV only
- Frame duration: 1–100 ms; default 10 ms
- Components per frame/channel: 1–4096; default 48
- KASF v1 frequency field tops out at 96 kHz
- Classic RIFF/WAV Base output is limited to less than 4 GiB of PCM data

The RIFF parser rejects unsupported encodings and malformed data alignment. RF64/WAVE64, MP3/FLAC decoding, resampling, channel remapping, and non-integer Base PCM are outside the bridge.

## Quick start

Run from the project directory.

### 1. Build the native C++ engine

```bash
python -m krm_proto.fastgen build
```

The binary is placed under `krm_proto/native/bin/` for the current platform. It is generated locally and is not bundled as a platform-specific executable in this source package.

### 2. Generate KASF v1 only

```bash
python -m krm_proto.fastgen generate \
  --input source.wav \
  --output output.kasf \
  --frame-ms 10 \
  --max-components 48 \
  --threshold-db -58 \
  --min-hz 15 \
  --tracker-assignment greedy
```

Use `--tracker-assignment hungarian` to run the optional global assignment comparison.

### 3. Generate KASF and experimental Reader Base WAV together

```bash
python -m krm_proto.fastgen generate \
  --input source.wav \
  --output output.kasf \
  --base-wav base-local-reader.wav
```

### 4. Run the full FastGen → KRC → KRM-IF bridge

```bash
python -m krm_proto.fastgen bridge \
  --source source.wav \
  --kasf output.kasf \
  --base base-local-reader.wav \
  --krmi capture.krmi \
  --chunk-samples 65536
```

The same operation is available through the main KRM CLI as `bridge-fast`:

```bash
python -m krm_proto bridge-fast \
  --source source.wav --kasf output.kasf \
  --base base-local-reader.wav --krmi capture.krmi
```

If the KRC stage is interrupted and leaves `capture.krmi.partial` plus `capture.krmi.journal.json`, rerun with the same Source/KASF/Base/KRM-IF paths and the same chunk size, adding `--resume`. FastGen and Reader rendering are skipped; the Source, KASF and Base hashes are checked before the committed KRC prefix is replayed and validated:

```bash
python -m krm_proto bridge-fast \
  --source source.wav --kasf output.kasf \
  --base base-local-reader.wav --krmi capture.krmi \
  --chunk-samples 65536 --resume
```

Do not use `--force` with `--resume`. `--force` discards the existing partial KRM capture and regenerates the KASF/Base outputs.

### 5. Verify and restore exact Source PCM

```bash
python -m krm_proto verify --input capture.krmi --source source.wav
python -m krm_proto restore --input capture.krmi --output restored.wav
```

The restored PCM frame bytes must exactly match the Source WAV's PCM frame bytes. The Base is deliberately lossy; exactness comes from retaining the full residual.

### Python API

```python
from krm_proto.fastgen import build_native, generate_and_capture

binary = build_native()  # auto-selects g++ or clang++
result = generate_and_capture(
    "source.wav",
    "output.kasf",
    "base-local-reader.wav",
    "capture.krmi",
    frame_ms=10.0,
    max_components=48,
    threshold_db=-58.0,
    min_hz=15.0,
    edge_pad=True,
    temporal_tracking=True,
    temporal_refinement=False,  # experimental; leave disabled for normal runs
    chunk_samples=65_536,
    binary=binary,
)
print(result["status"])
```

By default, `generate_kasf()` also writes a track-map JSONL sidecar. Disable tracking with `temporal_tracking=False` or CLI `--no-tracking`. `temporal_refinement=True` / `--experimental-track-refine` changes KASF component values and is for controlled experiments only.

The slower Python reference implementation is available separately:

```python
from krm_proto.fastgen import render_kasf_to_base_wav
render_kasf_to_base_wav("output.kasf", "source.wav", "base-python-reference.wav")
```

## PCM quantization and Base provenance

Experimental quantizer identifier:

```text
KRM-PROTO-PCM-Q-v1
signed PCM scale = 2^(bits-1)
rounding = floor(value * scale + 0.5)
clipping = saturate to the target signed integer range
non-finite input = 0
normalization = none
```

The rounding emulates JavaScript `Math.round()` for the finite Reader values expected here. This is a KRM prototype policy, **not a discovered official KASF float-to-integer export specification**. Metadata explicitly stores the profile, local Reader identity, Source/KASF/Base SHA-256 hashes, frame geometry, edge-guard length, and `canonical_kasf_export: false`.

## Current measured validation

A reproducible synthetic 10-second, 48 kHz, stereo, 16-bit WAV was generated with two channels of three sinusoidal/chirped components. On the current test container:

| Measurement | Result |
|---|---:|
| C++ FastGen + native Base process wall time | 0.82 s |
| C++ frame-loop timer (native reported) | 0.8096 s |
| Full FastGen → native Base → KRC capture wall time | 4.296 s |
| Audio duration / native process wall time | 12.20× |
| KASF output | 158,294 bytes |
| Native Base WAV | 1,920,044 bytes |
| KRM-IF output | 15,362,942 bytes |
| Source/Base SNR | 51.87 dB |
| Native C++ Base vs Python reference Base | byte-identical, 1,920,000 PCM bytes |
| KRM exact verification | PASS; 960,000 channel samples checked |
| Restored Source PCM | byte-identical to input PCM |

These measurements are from the current execution environment and this one synthetic signal; they are not a speed or quality guarantee for music, speech, long recordings, or the user's computer.

A separate cross-runtime comparison used the actual `KASF05_Reader` source extracted from the user's Rev.0.9.20 HTML:

- 10 seconds, 48 kHz, stereo; guarded Reader timeline 480,480 samples/channel.
- Compared 960,960 float64 values (both channels).
- Maximum absolute difference between Python and actual JavaScript Reader output: `2.220446049250313e-16`.
- Mean absolute difference: `2.5901627633556662e-18`.
- The two floating-point arrays are not bit-identical because of runtime transcendental rounding. Their quantized PCM Base WAVs were byte-identical in this test.

See `docs/TEST-REPORT.md` and `benchmarks/` for the saved measurements. `benchmarks/compare_tracker_assignment.py` can compare Greedy/Hungarian on a user-supplied PCM WAV without modifying the source.

## Other KRM functionality

Draft 0.6 retains the Draft 0.5 KRM prototype features:

- resumable KRC capture with journal and block integrity;
- KRM-IF prototype physical container v0.2 with CRC-32C and SHA-256;
- exact WAV and raw PCM restore;
- streaming residual energy-event probe;
- streaming integer predictor verification;
- KRM-FC candidate data model and validation;
- KASF v1 diagnostic decoder and streaming float64 OLA renderer;
- source/reader/base provenance metadata.

The physical KRM-IF container remains prototype revision 0.2. No compression has been added: Base and Raw Residual are stored as signed int64 pairs, so KRM-IF can be larger than the original audio.

## Known limitations / next work

- FastGen is a baseline encoder, not a full KASF Rev.0.9.20 port.
- Temporal tracks are metadata associations only. Greedy is the default; optional Hungarian assignment reduces some local conflicts but real-audio tracks remain fragmented. Harmonic grouping, stereo linking, and perceptual source tracking are not implemented.
- Default tracking does not alter component phases/frequencies. Experimental phase-derived frequency refinement is opt-in and has shown regressions on synthetic tests.
- Edge guards use component extrapolation; abrupt starts/stops and percussive attacks may not benefit.
- Native Base uses the local Reader equation and an explicit experimental quantizer; the final app-wide Reader/export chain is not proven.
- KASF v1 header omits source rate/sample count; sidecar integrity is required.
- KRM-IF remains uncompressed and prototype-only; recovery journal is separate from the container.
- KRM analysis currently has energy event probes, not production HPSS/MP/EMD/VMD/SST implementations.

The current Hungarian association solver remains experimental and Greedy stays default. Run `python benchmarks/compare_tracker_assignment.py /path/to/source.wav` to compare modes and inspect track lifetimes on your own PCM WAV.

The next correctness milestone is a fully specified Source-domain adapter that reproduces KASF's own decode/resample/channel mapping, then a proof of parity against the complete intended Reader/export pipeline. Only after that should KRM call its Base canonical.

### Recreate the benchmark input

```bash
python benchmarks/make_benchmark_wav.py
```

Then run the FastGen or `bridge` commands above against `benchmarks/bench_48k_stereo.wav`.

### Run the test suite

```bash
python -m compileall -q krm_proto tests examples benchmarks
python -m unittest discover -s tests -v
```

## What “exact match” means in this pipeline

These are different comparisons and must not be conflated:

1. **C++ Base vs Python Base:** two implementations of the same local Reader OLA + prototype PCM quantizer. Byte identity means the two renderers agree with each other.
2. **Source vs Base:** they are normally *not* identical. Base is a lossy reconstruction from KASF components; their difference is the Raw Residual.
3. **Source vs Restored:** after KRM adds the exact stored residual to Base, the restored PCM must be byte-identical to Source. This is the KRM lossless-restoration test.

The formula is `Source = Base + Residual`. A perfect Source/Base match is neither expected nor required for KRM to restore Source exactly.
