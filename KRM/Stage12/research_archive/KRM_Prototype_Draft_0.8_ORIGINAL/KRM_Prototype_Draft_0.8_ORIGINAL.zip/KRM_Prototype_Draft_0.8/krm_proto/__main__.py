from __future__ import annotations

import argparse
import json
from pathlib import Path

from .capture import capture_residual
from .fastgen import generate_kasf, generate_and_capture
from .container import iter_blocks, read_file_header
from .events import (
    P2Quantile,
    StreamingEnergyEventDetector,
    StreamingFrameFeatures,
)
from .predictor import StreamingPredictorVerifier
from .restore import inspect_krmi, restore_krmi, restore_raw_pcm, verify_krmi


def analyze_krmi_streaming(
    path: str | Path,
    window_samples: int,
    hop_samples: int,
    threshold: float | None,
    baseline_multiplier: float,
    absolute_floor: float,
    merge_gap_frames: int,
) -> dict:
    """Analyze all channels with one file scan per pass, bounded by block/window size."""
    with open(path, "rb") as fp:
        manifest, _, _ = read_file_header(fp)
    channels = int(manifest["audio"]["channels"])
    sample_rate = int(manifest["audio"]["sample_rate_hz"])
    extractors = [StreamingFrameFeatures(window_samples, hop_samples) for _ in range(channels)]

    if threshold is None:
        estimators = [P2Quantile(0.5) for _ in range(channels)]
        with open(path, "rb") as fp:
            _, _, _ = read_file_header(fp)
            for block in iter_blocks(fp, manifest):
                for ch in range(channels):
                    for frame in extractors[ch].feed(block.residual[ch]):
                        estimators[ch].add(frame["rms"])
        for ch in range(channels):
            for frame in extractors[ch].finish():
                estimators[ch].add(frame["rms"])
        thresholds = [max(absolute_floor, estimator.value * baseline_multiplier) for estimator in estimators]
        threshold_method = "two-pass P² approximate median"
    else:
        thresholds = [float(threshold)] * channels
        threshold_method = "user-supplied fixed threshold"

    detectors = [StreamingEnergyEventDetector(thresholds[ch], merge_gap_frames) for ch in range(channels)]
    extractors = [StreamingFrameFeatures(window_samples, hop_samples) for _ in range(channels)]
    with open(path, "rb") as fp:
        _, _, _ = read_file_header(fp)
        for block in iter_blocks(fp, manifest):
            for ch in range(channels):
                for frame in extractors[ch].feed(block.residual[ch]):
                    detectors[ch].feed(frame)
    results = []
    for ch in range(channels):
        for frame in extractors[ch].finish():
            detectors[ch].feed(frame)
        result = detectors[ch].finish()
        result.update({
            "channel": ch,
            "threshold_method": threshold_method,
            "window_samples": window_samples,
            "hop_samples": hop_samples,
            "event_semantics": "energy_activity_candidate; not a source-class or MP event label",
        })
        results.append(result)

    return {
        "sample_rate_hz": sample_rate,
        "sample_count_per_channel": int(manifest["audio"]["sample_count"]),
        "channels": results,
        "notice": "Coarse time-domain activity probe only; not MP, HPSS, STN, or source separation. Residual PCM is processed block-by-block.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="krm_proto",
        description="KRM/KRC/KRM-IF research prototype (not production software)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("capture", help="Create a KRM-IF file from Source and Base PCM WAV files")
    p.add_argument("--source", required=True)
    p.add_argument("--base", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--chunk-samples", type=int, default=65_536)
    p.add_argument("--resume", action="store_true", help="Resume a checkpointed capture; inputs are replayed from sample zero")

    p = sub.add_parser("restore", help="Restore a PCM WAV from KRM-IF Base + Residual")
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)

    p = sub.add_parser("restore-raw", help="Restore interleaved raw PCM (no RIFF/WAV 4 GiB limit)")
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)

    p = sub.add_parser("verify", help="Verify checksums and exact reconstructed PCM")
    p.add_argument("--input", required=True)
    p.add_argument("--source", help="Optional original WAV to compare against")

    p = sub.add_parser("inspect", help="Print KRM-IF manifest")
    p.add_argument("--input", required=True)

    p = sub.add_parser("analyze", help="Run bounded-memory residual energy activity analysis")
    p.add_argument("--input", required=True)
    p.add_argument("--window-samples", type=int, default=1024)
    p.add_argument("--hop-samples", type=int, default=512)
    p.add_argument("--threshold", type=float)
    p.add_argument("--baseline-multiplier", type=float, default=3.0)
    p.add_argument("--absolute-floor", type=float, default=1.0)
    p.add_argument("--merge-gap-frames", type=int, default=1)
    p.add_argument("--output-json")

    p = sub.add_parser("predict-demo", help="Run streaming exact integer order-1/order-2 predictor checks")
    p.add_argument("--input", required=True)

    p = sub.add_parser("generate-fast", help="Generate a KASF v1 file with the native C++ spectral-pursuit baseline")
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--frame-ms", type=float, default=10.0)
    p.add_argument("--max-components", type=int, default=48)
    p.add_argument("--threshold-db", type=float, default=-58.0)
    p.add_argument("--min-hz", type=float, default=15.0)
    p.add_argument("--no-edge-pad", action="store_true", help="Disable half-window pre/post guard frames")
    p.add_argument("--no-tracking", action="store_true", help="Disable temporal component association metadata")
    p.add_argument("--experimental-track-refine", action="store_true", help="Enable experimental audio-changing phase-derived frequency refinement")
    p.add_argument("--tracker-assignment", choices=("greedy", "hungarian"), default="greedy")
    p.add_argument("--base-wav", help="Also emit experimental local-Reader Base WAV")
    p.add_argument("--force", action="store_true")
    p.add_argument("--binary")

    p = sub.add_parser("bridge-fast", help="FastGen -> KASF Reader -> Base WAV -> KRC/KRM-IF in one run")
    p.add_argument("--source", required=True)
    p.add_argument("--kasf", required=True)
    p.add_argument("--base", required=True)
    p.add_argument("--krmi", required=True)
    p.add_argument("--frame-ms", type=float, default=10.0)
    p.add_argument("--max-components", type=int, default=48)
    p.add_argument("--threshold-db", type=float, default=-58.0)
    p.add_argument("--min-hz", type=float, default=15.0)
    p.add_argument("--no-edge-pad", action="store_true", help="Disable half-window pre/post guard frames")
    p.add_argument("--no-tracking", action="store_true", help="Disable temporal component association metadata")
    p.add_argument("--experimental-track-refine", action="store_true", help="Enable experimental audio-changing phase-derived frequency refinement")
    p.add_argument("--tracker-assignment", choices=("greedy", "hungarian"), default="greedy")
    p.add_argument("--chunk-samples", type=int, default=65_536)
    p.add_argument("--resume", action="store_true", help="Resume KRC capture using the saved KASF and Base WAV")
    p.add_argument("--force", action="store_true")
    p.add_argument("--binary")

    args = parser.parse_args()
    if args.command == "capture":
        manifest = capture_residual(args.source, args.base, args.output, args.chunk_samples, resume=args.resume)
        print(json.dumps({"status": "CREATED", "output": args.output, "audio": manifest["audio"], "container": manifest["container"]}, ensure_ascii=False, indent=2))
    elif args.command == "restore":
        result = restore_krmi(args.input, args.output)
        print(json.dumps({"status": "RESTORED", "output": args.output, **result}, ensure_ascii=False, indent=2))
    elif args.command == "restore-raw":
        result = restore_raw_pcm(args.input, args.output)
        print(json.dumps({"status": "RESTORED_RAW_PCM", "output": args.output, **result}, ensure_ascii=False, indent=2))
    elif args.command == "verify":
        print(json.dumps(verify_krmi(args.input, args.source), ensure_ascii=False, indent=2))
    elif args.command == "inspect":
        print(json.dumps(inspect_krmi(args.input), ensure_ascii=False, indent=2))
    elif args.command == "analyze":
        if args.window_samples < 1 or args.hop_samples < 1:
            raise SystemExit("window-samples and hop-samples must be positive")
        if args.baseline_multiplier <= 0 or args.absolute_floor < 0 or args.merge_gap_frames < 0:
            raise SystemExit("Invalid event detector parameters")
        payload = analyze_krmi_streaming(
            args.input, args.window_samples, args.hop_samples, args.threshold,
            args.baseline_multiplier, args.absolute_floor, args.merge_gap_frames,
        )
        rendered = json.dumps(payload, ensure_ascii=False, indent=2)
        if args.output_json:
            Path(args.output_json).write_text(rendered, encoding="utf-8")
        print(rendered)
    elif args.command == "generate-fast":
        result = generate_kasf(args.input, args.output, frame_ms=args.frame_ms,
            max_components=args.max_components, threshold_db=args.threshold_db,
            min_hz=args.min_hz, edge_pad=not args.no_edge_pad,
            temporal_tracking=not args.no_tracking,
            temporal_refinement=args.experimental_track_refine, tracker_assignment=args.tracker_assignment,
            base_wav=args.base_wav, force=args.force, binary=args.binary)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.command == "bridge-fast":
        result = generate_and_capture(args.source, args.kasf, args.base, args.krmi,
            frame_ms=args.frame_ms, max_components=args.max_components,
            threshold_db=args.threshold_db, min_hz=args.min_hz,
            edge_pad=not args.no_edge_pad, temporal_tracking=not args.no_tracking,
            temporal_refinement=args.experimental_track_refine, tracker_assignment=args.tracker_assignment,
            chunk_samples=args.chunk_samples, force=args.force, resume=args.resume, binary=args.binary)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.command == "predict-demo":
        with open(args.input, "rb") as fp:
            manifest, _, _ = read_file_header(fp)
            channel_count = int(manifest["audio"]["channels"])
            verifiers = [[StreamingPredictorVerifier(order) for order in (1, 2)] for _ in range(channel_count)]
            for block in iter_blocks(fp, manifest):
                for channel in range(channel_count):
                    for verifier in verifiers[channel]:
                        verifier.feed(block.residual[channel])
        reports = []
        for channel in range(channel_count):
            for verifier in verifiers[channel]:
                reports.append(verifier.finish() | {"channel": channel})
        if not all(report["exact"] for report in reports):
            raise SystemExit("Predictor round-trip failed")
        print(json.dumps({"status": "PASS", "reports": reports}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
